## Exercise 1: Hello World

In this exercise, we will create a Hello World endpoint.

* Create a new folder src/main/resources (if it doesn't exist already)
* Add an empty `application.properties` file
* Create a new `hello` endpoint on the existing `GreetingResource`, with path
  parameter `subject`, and make it return `Hello` plus the subject. So that
  you can go to http://localhost:8080/hello/world to see `Hello World`

