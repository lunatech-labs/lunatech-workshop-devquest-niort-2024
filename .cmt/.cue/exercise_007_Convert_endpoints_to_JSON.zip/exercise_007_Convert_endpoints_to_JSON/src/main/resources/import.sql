INSERT into Product (id, name, description, price) VALUES (1, 'Chair', 'A metal frame chair, with oak seat', 59.95);
INSERT into Product (id, name, description, price) VALUES (2, 'Dinner Table', 'Sturdy oak Table', 200);
INSERT into Product (id, name, description, price) VALUES (3, 'Coffee Table', 'An oak coffee Table', 120);
INSERT into Product (id, name, description, price) VALUES (4, 'Side Table', 'A Nice little oak side table', 80);
INSERT into Product (id, name, description, price) VALUES (5, 'Mirror', 'A round mirror with oak frame', 80);
INSERT into Product (id, name, description, price) VALUES (6, 'Lamp', 'A light that shines', 45);
INSERT into Product (id, name, description, price) VALUES (7, 'Carpet', 'Soft carpet', 39.95);
